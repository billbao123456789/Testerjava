package com.basic.bai1;

import java.util.*;

public class CalculateUtils {
	public static double tinhCong(double x, double y) {
		double tinhTong=x+y;
		return tinhTong;
	}
   public static double tinhTru(double x, double y) {
    	double tinhTru=x-y;
    	return tinhTru;
	       
	}
    public static double tinhNhan(double x, double y) {
    	double tinhNhan=x*y;
    	return tinhNhan;
    }
	public static double tinhChia(double x, double y) throws Exception {
		//if(y==0) throw new Exception("(y=0)->Lỗi chia cho 0");
		double tinhChia=x/y;
    	return tinhChia;
		
	}
	
}
