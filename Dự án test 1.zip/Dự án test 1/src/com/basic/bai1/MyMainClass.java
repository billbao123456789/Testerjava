package com.basic.bai1;
import java.util.*;
public class MyMainClass {
   public static void main(String []args) throws Exception {
//	   Bai1 obj=new Bai1();
//	   obj.tinhCong(10,3);
//	   obj.tinhTru(10, 3);
//	   obj.tinhChia(10, 2);
//	   obj.tinhNhan(10, 5);
	   CalculateUtils CU=new CalculateUtils();
	   Scanner scanner=new Scanner(System.in);
       System.out.print("Nhập số thứ 1:");
       double x=scanner.nextDouble();
       System.out.print("Nhập số thứ 2:");
       double y=scanner.nextDouble();
       System.out.print("Nhập lệnh Action:");
       String ACTION=scanner.next().toUpperCase();
       String message;
       try
       {
		   switch(ACTION) {
		   case "CONG":
			   double CONG = CU.tinhCong(x, y);
			   System.out.println("Ket qua CONG = " + CONG + "\n");
			   break;
		   case "TRU":
			   double TRU = CU.tinhTru(x, y);
			   System.out.println("Ket qua TRU = " + TRU + "\n");
			   break;
		   case "NHAN":
			   double NHAN = CU.tinhNhan(x, y);
			   System.out.println("Ket qua NHAN = " + NHAN + "\n");
			   break;
		   case "CHIA":
			   double CHIA = CU.tinhChia(x, y);
			   System.out.println("Ket qua CHIA = " + CHIA + "\n");
			   break;
		   default:
				message = "Gia tri ACTION khong hop le";
				System.out.println(message);
		   }	   
       }
       catch(Exception e) {
    	   System.out.println(e.getMessage());
       }
	  
      
   }
}

