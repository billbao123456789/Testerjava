package com.basic.bai3;

import java.util.*;

public class student {
	private String fullName;
	private String address;
	private String dob;
	private String gender;
	private float finalGrade;
	public student() {}
	public student(String fullName, String address, String dob, String gender, float finalGrade) {
		this.fullName = fullName;
		this.address = address;
		this.dob = dob;
		this.gender = gender;
		this.finalGrade = finalGrade;
	}

	public void setfullName(String fullName) {
		if (fullName == null || fullName.isEmpty()) {
			this.fullName = "Không biết";
		} else {
			this.fullName = fullName;
		}
	}

	public String getfullName() {
		return fullName;
	}

	public void setdob(String dob) {
		if (dob == null || dob.isEmpty()) {
			this.dob = "Không biết";
		} else {
			this.dob = dob;
		}
	}

	public String getdob() {
		return dob;
	}

	public void setAddress(String address) {
		if (address == null || address.isEmpty()) {
			this.address = "Địa chỉ không hợp lệ";
		} else {
			this.address = address;
		}
	}

	public String getAddress() {
		return address;
	}

	public void setGender(String gender) {
		if (gender == null || gender.isEmpty()) {
			this.gender = "Nam";
		} else if (gender == null || gender.isEmpty()) {
			this.gender = "Nữ";
		} else {
			this.gender = "Khác";
		}
	}

	public String getGender() {
		return gender;
	}

	public float getfinalGrade() {
		return finalGrade;
	}

	public void setfinalGrade(float finalGrade) {
		this.finalGrade = finalGrade;
	}
//	public void Inthongtin(ArrayList<student> list) {
//		student st = new student();
//    	for(int i=0;i<list.size();i++) {
//    		System.out.println("----------------------------------");
//    		System.out.println("Student "+(i+1)+":");
//    		System.out.println("fullName: "+ list.get(i).getfullName());
//    		System.out.println("Address: "+list.get(i).getAddress());
//    		System.out.println("DOB: "+list.get(i).getdob());
//    		System.out.println("Gender: "+list.get(i).getGender());
//    		System.out.println("FinalGrade: "+list.get(i).getfinalGrade());
//    		st.evaluateStudent(list.get(i).getfullName(), list.get(i).getfinalGrade());
//    	}
//    }
//	public void evaluateStudent(String fullName, double finalGrade) {
//		if (finalGrade < 4) {
//			System.out.println("Hoc sinh " + fullName + " học lực kém ");
//		} else if (4 <= finalGrade && finalGrade < 5) {
//			System.out.println("Hoc sinh " + fullName + " học lực yếu ");
//		} else if (5.0 <= finalGrade && finalGrade < 5.5) {
//			System.out.println("Hoc sinh " + fullName + " học lực TB yếu ");
//		} else if (5.5 <= finalGrade && finalGrade < 6.5) {
//			System.out.println("Hoc sinh " + fullName + " học lực TB ");
//		} else if (6.5 <= finalGrade && finalGrade < 7.0) {
//			System.out.println("Hoc sinh " + fullName + " học lực TB khá ");
//		} else if (7.0 <= finalGrade && finalGrade < 8.0) {
//			System.out.println("Hoc sinh " + fullName + " học lực khá ");
//		} else if (8.0 <= finalGrade && finalGrade < 8.5) {
//			System.out.println("Hoc sinh " + fullName + " học lực khá giỏi ");
//		} else if (8.5 <= finalGrade && finalGrade <= 10.0) {
//			System.out.println("Hoc sinh " + fullName + " học lực giỏi ");
//		} else {
//			System.out.println("Điểm của học sinh" + fullName + "không hợp lệ");
//		}
//	}
}
