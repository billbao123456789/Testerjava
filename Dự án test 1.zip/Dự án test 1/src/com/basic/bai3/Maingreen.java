package com.basic.bai3;

import java.util.*;

public class Maingreen {
	static Scanner sc = new Scanner(System.in);
	static Maingreen mg = new Maingreen();
	// Nhập thông tin từ mảng và in ra thông tin từ mảng
	public static void main(String[] args) {//chỉ dc chạy trong main
		ArrayList<student> list = new ArrayList<student>();
		while (true) {
			student st = new student(null, null, null, null, 0);
			System.out.print("Vui lòng nhập tên học sinh");
			String fullName = sc.nextLine();
			st.setfullName(fullName);

			System.out.print("Vui lòng nhập địa chỉ học sinh");
			String address = sc.nextLine();
			st.setAddress(address);

			System.out.print("Vui lòng nhập ngày tháng năm sinh học sinh");
			String dob = sc.nextLine();
			st.setdob(dob);

			System.out.print("Vui lòng nhập giới tính học sinh");
			String gender = sc.nextLine();
			st.setGender(gender);

			System.out.print("Vui lòng nhập điểm số học sinh");
			float finalGrade = sc.nextFloat();
			sc.nextLine();
			st.setfinalGrade(finalGrade);
			list.add(st);

			System.out.print("Do you want to continue (Y/N)?");
			String confirm = sc.nextLine();
			if (confirm.equalsIgnoreCase("N")) {
				break;
			}
		}
		mg.Inthongtin(list);//cái nào có static rồi ko cần mg.
		inthongtinDiemTB(list);
	}

	// In thông ra student
    public void Inthongtin(ArrayList<student> list) {
    	for(int i=0;i<list.size();i++) {
    		System.out.println("----------------------------------");
    		System.out.println("Student "+(i+1)+":");
    		System.out.println("fullName: "+ list.get(i).getfullName());
    		System.out.println("Address: "+list.get(i).getAddress());
    		System.out.println("DOB: "+list.get(i).getdob());
    		System.out.println("Gender: "+list.get(i).getGender());
    		System.out.println("FinalGrade: "+list.get(i).getfinalGrade());
    		mg.evaluateStudent(list.get(i).getfullName(), list.get(i).getfinalGrade());
    	}
    	
    }
	// In ra điểm số học viên
	public void evaluateStudent(String fullName, double finalGrade) {
		if (finalGrade < 4) {
			System.out.println("Hoc sinh " + fullName + " học lực kém ");
		} else if (4 <= finalGrade && finalGrade < 5) {
			System.out.println("Hoc sinh " + fullName + " học lực yếu ");
		} else if (5.0 <= finalGrade && finalGrade < 5.5) {
			System.out.println("Hoc sinh " + fullName + " học lực TB yếu ");
		} else if (5.5 <= finalGrade && finalGrade < 6.5) {
			System.out.println("Hoc sinh " + fullName + " học lực TB ");
		} else if (6.5 <= finalGrade && finalGrade < 7.0) {
			System.out.println("Hoc sinh " + fullName + " học lực TB khá ");
		} else if (7.0 <= finalGrade && finalGrade < 8.0) {
			System.out.println("Hoc sinh " + fullName + " học lực khá ");
		} else if (8.0 <= finalGrade && finalGrade < 8.5) {
			System.out.println("Hoc sinh " + fullName + " học lực khá giỏi ");
		} else if (8.5 <= finalGrade && finalGrade <= 10.0) {
			System.out.println("Hoc sinh " + fullName + " học lực giỏi ");
		} else {
			System.out.println("Điểm của học sinh" + fullName + "không hợp lệ");
		}
	}
	//In ra điểm trung bình
	public static void DiemTB(ArrayList<student> students) {
		float _diemTrungBinh = 0;
		for (student student : students) {
			_diemTrungBinh += student.getfinalGrade();
		}
		System.out.println("Điểm TB = " + _diemTrungBinh/students.size());
	}
	
	public static void inthongtinDiemTB(ArrayList<student> students) {
	    	float _tongdiem=0;//sv 0=Nam, 1=Hong, 2=..., chỉ arraylist
	    	for(int i=0;i<students.size();i++) {
	    		_tongdiem +=students.get(i).getfinalGrade();
	    	}
	    	System.out.println("Điểm TB="+_tongdiem/students.size());
	}
	
}
