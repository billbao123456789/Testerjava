package com.basic.bai2;

import java.util.*;

public class Mainscreen {
	//Nhập vào số nguyên bất kỳ từ bàn phím 
	public static void main(String []args) throws Exception {
		Scanner sc=new Scanner(System.in);
		//int tieptuc=1;
		
		while(true) //CHUA XÁC ĐỊNH LẬP BAO NHIÊU LẦN, I>N HOẶC I<N LÀ XÁC ĐỊNH BN LẦN
		{
			
			try {
				System.out.print("Nhập vào số nguyên dương N:");
				int N = Integer.parseInt(sc.nextLine());
				int sumchan = 0;
				int sumle = 0;
				int count = 0;
				String listcount = "";
				if (N > 0) {
					for (int i = 0; i <= N; i++) {
						if (i % 2 == 0) {
							sumchan = sumchan + i;
						} else if (i % 2 != 0) {
							sumle = sumle + i;
						}
						if (i % 3 == 0 && i % 2 != 0) {
							count = count + 1;//0%3 MÀ KO CHIA 2 1%3 ,3//ĐẾM XEM BN SỐ CHIA HẾT 3 MÀ KO CHIA 2
							if (listcount == "") {// IN RA SỐ ĐẤY LÀ SỐ NÀO
								listcount = listcount + "" + i;//3,5,15
							} else {
								listcount = listcount + "," + i;
							}
						}

					}
					System.out.println("Các biến sum chẵn " + sumchan);
					System.out.println("Các biến sum lẻ " + sumle);
					System.out.println("In ra số chia hết cho 3 nhưng không chia hết cho 2: " + listcount);
                    //tieptuc=2;
                    break;
				}
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			   	
			}
				
				
		}		
			
				
	}
}

